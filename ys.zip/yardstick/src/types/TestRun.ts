import { TestStep } from "./TestStep";

export class TestRun {
    id?: number;
    start?: Date;
    duration?: string;
    status?: string;
    environment?: string;
    version?: string;
    steps: TestStep[] = [];
}