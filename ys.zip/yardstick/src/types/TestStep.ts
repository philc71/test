export class TestStep {
    id?: number;
    name?: string;
    path?: string;
    group?: string;
    start?: Date;
    duration?: string;
    status?: string;
}