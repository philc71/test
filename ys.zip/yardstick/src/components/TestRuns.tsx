import * as React from 'react';
import { ITestContext } from '../context/ITestContext';
import { TestRun } from "../types";

export class TestRuns extends React.Component<ITestContext, any> {

    componentDidMount() {
    }

    public render() {
        return (
            <div>
                <div>TestRuns</div>
                <div>{this.props.context.testRuns.map((run: TestRun, i: number) => {
                    return (<div key={i}>{run.id}</div>)
                })}</div>
            </div>)
    }
}