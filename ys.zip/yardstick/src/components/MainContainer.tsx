import React from 'react';
import { TestRuns } from "./TestRuns";
import { TestProvider, TestConsumer, TestRepository } from "../context/TestContext";

export class MainContainer extends React.Component {

    // initialise the context/repo
    state: TestRepository = new TestRepository();

    componentDidMount() {

    }

    public render() {
        return (
            <TestProvider value={this.state}>
                <div className="App">
                    <TestConsumer>
                        {ctx => <TestRuns context={ctx} />}
                    </TestConsumer>
                </div>
            </TestProvider>
        );
    }
}