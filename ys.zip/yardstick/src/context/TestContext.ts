import React, { createContext } from 'react';
import { TestRun } from "../types";

export class TestRepository {
    testRuns: TestRun[] = [];
}

const TestContext = createContext<TestRepository>(new TestRepository());

export const TestProvider = TestContext.Provider;

export const TestConsumer = TestContext.Consumer;
