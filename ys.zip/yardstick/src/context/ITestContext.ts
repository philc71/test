import { TestRepository } from './TestContext';
export interface ITestContext {
    context: TestRepository;
}