﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Yardstick.Shared
{
    public class TestEvent
    {
        public TestEvent(TestEventEnum eventType, int runId, int? stepId = null)
        {
            EventType = eventType;
            RunId = runId;
            StepId = stepId;
        }

        public TestEventEnum EventType { get; private set; }
        public int RunId { get; private set; }
        public int? StepId { get; private set; }
    }
}
