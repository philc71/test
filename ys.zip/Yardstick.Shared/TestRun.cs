﻿using System;
using System.Collections.Generic;

namespace Yardstick.Shared
{
    public class TestRun
    {
        public TestRun()
        {
            Steps = new List<TestStep>();
        }

        public int Id { get; set; }
        public DateTime Start { get; set; }
        public DateTime Finish { get; set; }
        public string Duration { get; set; }
        public StatusEnum Status { get; set; }
        public EnvironmentEnum Environment { get; set; }
        public string Version { get; set; }
        public List<TestStep> Steps { get; set; }
        public int TotalTests => (TestsPassed + TestsFailed + TestsIgnored + TestsSkipped);

        public int TestsPassed { get; set; }
        public int TestsFailed { get; set; }
        public int TestsIgnored { get; set; }
        public int TestsSkipped { get; set; }

    }
}
