﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace Yardstick.Shared
{
    public enum EnvironmentEnum
    {
        [Description("DEV")]
        Development = 0,
        [Description("UAT")]
        UAT = 1,
    }

    public enum StatusEnum
    {
        [Description("NotStarted")]
        NotStarted = 0,
        [Description("Running")]
        Running = 1,
        [Description("Completed")]
        Completed = 2,
        [Description("Error")]
        Error = 3,
        [Description("Cancelled")]
        Cancelled = 4,
        [Description("Queued")]
        Queued = 5,
    }

    public enum TestEventEnum
    {
        [Description("Created")]
        Created = 0,
        [Description("Updated")]
        Updated = 1,
        [Description("Completed")]
        Completed = 2,
        [Description("Failed")]
        Failed = 3,
        [Description("Cancelled")]
        Cancelled = 4,
        [Description("Queued")]
        Queued = 5,
    }
}
