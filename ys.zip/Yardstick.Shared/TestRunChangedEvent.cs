﻿namespace Yardstick.Shared
{
    public class TestRunChangedEvent
    {
        public TestRunChangedEvent()
        {

        }

        public TestRunChangedEvent(int id)
        {
            Id = id;
        }

        public int Id { get; set; }
    }
}
