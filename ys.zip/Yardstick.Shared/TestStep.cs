﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Yardstick.Shared
{
    public class TestStep
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Path { get; set; }
        public string Group { get; set; }
        public DateTime Start { get; set; }
        public DateTime Finish { get; set; }
        public string Duration { get; set; }
        public StatusEnum Status { get; set; }
        public int TotalTests => (TestsPassed + TestsFailed + TestsIgnored + TestsSkipped);

        public int TestsPassed { get; set; }
        public int TestsFailed { get; set; }
        public int TestsIgnored { get; set; }
        public int TestsSkipped { get; set; }

    }
}
