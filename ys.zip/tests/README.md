1. To execute a single spec command = "npm run testspec" (parameters: testrunid, specname)
    e.g. > npm run testspec 99 myspec

2. To run a single spec in dev mode
    e.g. > npm run dev myspec

3. To run all
    e.g. > npm run test-all