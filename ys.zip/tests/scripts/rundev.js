const fs = require("fs");
const path = require("path");
const rimraf = require("rimraf");
const shell = require("shelljs");

const reportDir = path.join(__dirname, '..', 'reports', 'html');
rimraf(reportDir, () => { });

const args = process.argv.splice(2);
const configOverrides = {};

if (args !== undefined) {
    args.forEach((val, index) => {
        switch (index) {
            case 0:
                configOverrides['testname'] = val;
                console.log(`testname: ${val}`);
                break;
            case 1:
                configOverrides['testenv'] = val;
                console.log(`testenv: ${val}`);
                break;
            default:
                console.log(`unknown arg: ${val}`);
                break;
        }
    });
}

var commandline = `mocha --timeout 20000 --testenv ${configOverrides['testenv']} ./specs/**/${configOverrides['testname']}.spec.js`;
console.log(commandline);

shell.exec(`${commandline}`, (err, stdout, stderr) => {
    if (err) {
        console.log(err);
        throw err;
    }
});
