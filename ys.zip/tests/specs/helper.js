module.exports = {
    getArgs,
    createOutputDirectory,
    setPageWidth,
}

var puppeteer = require('puppeteer');
var fs = require('fs');

function getArgs() {
    var raw = process.argv.splice(2);
    var args = {
        testRun: 'TBD',
        environment: 'dev'
    }

    var previousVal = '';
    raw.forEach((val, index) => {
        switch (previousVal) {
            case "--testrun":
                args.testRun = val;
                break;
            case "--testenv":
                args.environment = val;
                break;
        }
        previousVal = val;
    });
    return args;
}

function createOutputDirectory(path) {
    var dir = `output/${path}`;
    console.log(`output directory: ${dir}`)
    if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir);
    }
}

// async function disableurl(page) {
//     await page.setRequestInterception(true);
//     page.on('request', request => {
//         var url = request.url();
//         if (url.endsWith('api/something')) {
//             request.respond({
//                 status: 200,
//                 contentType: 'application/json',
//                 body: '{ error: false}'
//             });
//         } else {
//             request.continue();
//         }
//     })
// }

async function setPageWidth(page, value) {
    const override = Object.assign(page.viewport(), { width: value });
    await page.setViewport(override);
}