var assert = require('assert');
var puppeteer = require('puppeteer');
const addContext = require('mochawesome/addContext');
var helper = require('../helper');

describe('AMAZOn', () => {

    var isHeaderless = false;
    var args = helper.getArgs();
    var screenshots = [];
    var browser;
    var page;

    beforeEach(function (done) {
        screenshots = [];
        done();
    });

    before(async () => {
        browser = await puppeteer.launch({
            headless: isHeaderless
        });
        page = await browser.newPage();
        helper.createOutputDirectory(args.testRun);
    });

    afterEach(async () => {
        if (screenshots !== undefined) {
            for (var i = 0; i < screenshots.length; i++) {
                var screenshot = screenshots[i];
                addContext(this, `./${screenshot}`);
            }
        }
        await browser.close();
    });

    it('2.0.1 - Simple Amazon Test', async () => {
        var testId = '2.0.1';
        try {
            await page.goto('https://www.amazon.co.uk/');

            await page.setViewport({ width: 2560, height: 1297 });


            await page.waitForSelector('.nav-searchbar #searchDropdownBox');
            await page.click('.nav-searchbar #searchDropdownBox');

            await page.select('.nav-searchbar #searchDropdownBox', 'search-alias=mobile-apps');

            await page.waitForSelector('.nav-searchbar #searchDropdownBox');
            await page.click('.nav-searchbar #searchDropdownBox');

            await page.waitForSelector('#nav-search > .nav-searchbar > .nav-right > .nav-search-submit > .nav-input');
            await page.click('#nav-search > .nav-searchbar > .nav-right > .nav-search-submit > .nav-input');


            if (!isHeaderless) {
                await page.waitFor(3000);
            }

            var screenshot = `${testId}.png`;
            screenshots.push(screenshot);
            await page.screenshot({ path: `output/${args.testRun}/${screenshot}` });

        } catch (err) {
            var screenshot = `${testId}.error.png`;
            screenshots.push(screenshot);
            await page.screenshot({ path: `output/${args.testRun}/${screenshot}` });
            assert.fail(err);
        }
    })
});

