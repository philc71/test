var assert = require('assert');
var puppeteer = require('puppeteer');
const addContext = require('mochawesome/addContext');
var helper = require('../helper');

describe('GTest', () => {

    var isHeaderless = false;
    var args = helper.getArgs();
    var screenshots = [];
    var browser;
    var page;

    beforeEach(function (done) {
        screenshots = [];
        done();
    });

    before(async () => {
        browser = await puppeteer.launch({
            headless: isHeaderless
        });
        page = await browser.newPage();
        helper.createOutputDirectory(args.testRun);
    });

    afterEach(async () => {
        if (screenshots !== undefined) {
            for (var i = 0; i < screenshots.length; i++) {
                var screenshot = screenshots[i];
                addContext(this, `./${screenshot}`);
            }
        }
        await browser.close();
    });

    it('1.0.1 - Simple Google Test', async () => {
        var testId = '1.0.1';
        try {
            await page.goto('https://www.google.co.uk/')

            await page.setViewport({ width: 2327, height: 1179 })

            await page.waitForSelector('.A8SBwf > .RNNXgb > .SDkEP > .a4bIc > .gLFyf')
            await page.click('.A8SBwf > .RNNXgb > .SDkEP > .a4bIc > .gLFyf')

            if (!isHeaderless) {
                await page.waitFor(3000);
            }

            var screenshot = `${testId}.png`;
            screenshots.push(screenshot);
            await page.screenshot({ path: `output/${args.testRun}/${screenshot}` });

        } catch (err) {
            var screenshot = `${testId}.error.png`;
            screenshots.push(screenshot);
            await page.screenshot({ path: `output/${args.testRun}/${screenshot}` });
            assert.fail(err);
        }
    })
});
