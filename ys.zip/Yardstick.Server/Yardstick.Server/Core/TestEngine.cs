﻿using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Dynamic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using Yardstick.Shared;

namespace Yardstick.Server.Core
{
    public class TestEngine
    {
        TestRepository _TestRepository;
        IConfiguration _Configuration;

        private HttpClient _HttpClient;
        private ExpandoObjectConverter _ExpConverter;
        private int _MaximumStepTime = 180000;

        private Queue<Tuple<TestRun, TestStep>> _StepQueue;
        private bool _IsProcessing = false;

        Dictionary<int, List<Process>> _RunningProcesses = new Dictionary<int, List<Process>>();

        private int _MaxProcesses = 1;
        private int _NbrCurrentProcesses = 0;

        public TestEngine(TestRepository testRepository, IConfiguration configuration)
        {
            try
            {
                _TestRepository = testRepository;
                _Configuration = configuration;

                _StepQueue = new Queue<Tuple<TestRun, TestStep>>();
                _HttpClient = new HttpClient();
                _ExpConverter = new ExpandoObjectConverter();

                int.TryParse(_Configuration["MaximumStepTime"], out _MaximumStepTime);
                int.TryParse(_Configuration["MaxProcesses"], out _MaxProcesses);
                if (_MaxProcesses < 1)
                {
                    _MaxProcesses = 1;
                }

                _TestRepository.OnChange.Subscribe(x =>
                {
                    if (x != null)
                    {
                        switch (x.EventType)
                        {
                            case TestEventEnum.Created:
                                Task.Factory.StartNew((evt) =>
                                {
                                    StartTestRun((TestEvent)evt);
                                }, x, TaskCreationOptions.LongRunning);
                                break;
                            case TestEventEnum.Cancelled:
                                Task.Factory.StartNew((evt) =>
                                {
                                    CancelTestRun((TestEvent)evt);
                                }, x);
                                break;
                            case TestEventEnum.Queued:
                                Task.Factory.StartNew((evt) =>
                                {
                                    QueueStep((TestEvent)evt);
                                }, x);
                                break;
                        }
                    }
                });

            }
            catch (Exception ex)
            {
                // log me
            }
        }

        private async Task StartTestRun(TestEvent ev)
        {
            var run = _TestRepository.GetTestRun(ev.RunId);
            if (run == null)
            {
                return;
            }

            try
            {
                InitialiseTestRun(run);
                await SetVersion(run);

                _RunningProcesses[run.Id] = new List<Process>();

                run.Steps.ForEach(step =>
                {
                    step.Status = StatusEnum.Queued;
                    _StepQueue.Enqueue(new Tuple<TestRun, TestStep>(run, step));
                });

                StartProcessing();
            }
            catch (Exception ex)
            {
                // log me
                run.Status = StatusEnum.Error;
                run.Finish = DateTime.UtcNow;
            }
            finally
            {
                _TestRepository.PersistChanges(run.Id);
            }
        }

        private void InitialiseTestRun(TestRun run)
        {
            try
            {
                run.Status = StatusEnum.Running;
                run.Steps = GenerateTestSteps();
                _TestRepository.PersistChanges(run.Id);
                var path = Path.Combine(_Configuration["DataPath"], run.Id.ToString());
                if (Directory.Exists(path))
                {
                    Directory.Delete(path, true);
                }
                Directory.CreateDirectory(path);
            }
            catch (Exception ex)
            {
                // log me
            }
        }

        private List<TestStep> GenerateTestSteps()
        {            
            try
            {
                var path = Path.Combine(_Configuration["TestPath"]);
                int id = 0;
                var steps = new List<TestStep>();

                foreach(var directory in Directory.GetDirectories(path))
                {
                    var groupSteps = new List<TestStep>();
                    var idx = directory.LastIndexOf("\\");
                    var group = directory.Substring(idx + 1, directory.Length - (idx + 1));

                    var groupId = group.Substring(0, group.IndexOf("-"));
                    group = group.Replace($"{groupId}-", "");

                    foreach (var file in Directory.GetFiles(directory))
                    {
                        if (file.EndsWith(".spec.js"))
                        {
                            idx = file.LastIndexOf("\\");
                            var stepName = file.Substring(idx + 1, file.Length - (idx + 1));
                            stepName = stepName.Replace(".spec.js", "");

                            var stepId = stepName.Substring(0, stepName.IndexOf("-"));
                            stepId = stepId.Replace(".", "");

                            groupSteps.Add(new TestStep()
                            {
                                Id = int.Parse(stepId),
                                Path = file,
                                Name = stepName,
                                Group = group,
                                Status = StatusEnum.NotStarted
                            });
                        }
                    }

                    groupSteps.OrderBy(x => x.Id).ToList().ForEach(x => { x.Id = id++; });
                    steps.AddRange(groupSteps.OrderBy(x => x.Id));
                }

                return steps;
            }
            catch (Exception ex)
            {
                // log me
                throw ex;
            }
        }

        private async Task SetVersion(TestRun run)
        {
            try
            {
                //var endpoint = run.Environment == EnvironmentEnum.Development ? _Configuration["Environments:Dev"] : _Configuration["Environments:Dev"];

                //var result = await _HttpClient.GetStringAsync(endpoint + "version.json");
                //if (result != null)
                //{
                //    dynamic version = JsonConvert.DeserializeObject<ExpandoObject>(result, _ExpConverter);
                //    if (version != null)
                //    {
                //        run.Version = version.version.ToString();
                //    }
                //}
            }
            catch (Exception ex)
            {
                // log me
            }
        }

        private void StartProcessing()
        {
            try
            {
                if (_StepQueue != null && !_IsProcessing)
                {
                    Tuple<TestRun, TestStep> item;
                    while (_NbrCurrentProcesses < _MaxProcesses && _StepQueue.Count > 0)
                    {
                        _StepQueue.TryDequeue(out item);
                        if (item != null)
                        {
                            Interlocked.Increment(ref _NbrCurrentProcesses);
                            Task.Factory.StartNew((ctx) =>
                            {
                                ExecuteTestStep((Tuple<TestRun, TestStep>)ctx);
                            }, item, TaskCreationOptions.LongRunning);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                // log me
            }
        }

        private async Task ExecuteTestStep(Tuple<TestRun, TestStep> context)
        {
            if (context == null)
            {
                if (_StepQueue.Count > 0)
                {
                    StartProcessing();
                }
                return;
            }

            _IsProcessing = true;

            var run = context.Item1;
            var step = context.Item2;

            try
            {
                if (run.Status != StatusEnum.Cancelled)
                {
                    await ExecuteStep(run, step);
                }
                else
                {
                    step.Status = StatusEnum.Cancelled;
                }
            }
            catch (Exception ex)
            {
                step.Status = StatusEnum.Error;
            }
            finally
            {
                _IsProcessing = false;
                _TestRepository.PersistChanges(run.Id);
                Interlocked.Decrement(ref _NbrCurrentProcesses);
                StartProcessing();
            }
        }

        private async Task ExecuteStep(TestRun run, TestStep step)
        {
            try
            {
                if (run.Status == StatusEnum.Cancelled)
                {
                    step.Status = StatusEnum.Cancelled;
                    return;
                }

                step.Status = StatusEnum.Running;
                step.Start = DateTime.UtcNow;

                var path = Path.Combine(_Configuration["TestPath"], "runtest.bat");

                Process process = new Process();
                ProcessStartInfo startInfo = new ProcessStartInfo(path);
                startInfo.WindowStyle = ProcessWindowStyle.Hidden;
                startInfo.WorkingDirectory = _Configuration["TestPath"];
                startInfo.UseShellExecute = true;

                var outputPath = Path.Combine(_Configuration["DataPath"], run.Id.ToString(), step.Id.ToString() + "-output.txt");
                var reportPath = $"{run.Id}-{step.Id}";
                startInfo.Arguments = $"{reportPath} {step.Name}";
                process.StartInfo = startInfo;

                if (_RunningProcesses.ContainsKey(run.Id))
                {
                    _RunningProcesses[run.Id].Add(process);
                }

                process.Start();

                process.WaitForExit(_MaximumStepTime);

                step.Status = StatusEnum.Completed;
                CopyResults(run, step);
            }
            catch (Exception ex)
            {
                step.Status = StatusEnum.Error;
                // log me
            }
            finally
            {
                step.Finish = DateTime.UtcNow;
                UpdateRunInformation(run);
            }
        }

        private void CopyResults(TestRun run, TestStep step)
        {
            try
            {
                var destinationPath = Path.Combine(_Configuration["OutputPath"], run.Id.ToString(), step.Id.ToString());
                if (Directory.Exists(destinationPath))
                {
                    Directory.Delete(destinationPath, true);
                }

                var reportsPath = Path.Combine(_Configuration["ReportPath"], $"{run.Id}-{step.Id}");

                UpdateStepStats(step, reportsPath);
                MoveDirectory(reportsPath, destinationPath);

                var srcOutputPath = Path.Combine(_Configuration["OutputPath"], $"{run.Id}-{step.Id}");
                MoveDirectory(srcOutputPath, destinationPath);
            }
            catch (Exception ex)
            {
                //log me
            }
        }

        private void UpdateStepStats(TestStep step, string path)
        {
            try
            {
                var reportsPath = Path.Combine(path, $"{step.Name}.json");
                if (File.Exists(reportsPath))
                {
                    using (StreamReader r = new StreamReader(reportsPath))
                    {
                        var json = r.ReadToEnd();
                        dynamic stats = JsonConvert.DeserializeObject<ExpandoObject>(json, _ExpConverter);
                        if (stats != null)
                        {
                            int passed = 0;
                            int.TryParse(stats.stats.passes.ToString(), out passed);
                            step.TestsPassed = passed;

                            int skipped = 0;
                            int.TryParse(stats.stats.skipped.ToString(), out skipped);
                            step.TestsSkipped = skipped;

                            int failed = 0;
                            int.TryParse(stats.stats.failures.ToString(), out failed);
                            step.TestsFailed = failed;

                            int pending = 0;
                            int.TryParse(stats.stats.pending.ToString(), out pending);
                            step.TestsIgnored = pending;
                        }
                    }
                }
            }
            catch (Exception ex)
            {

            }
        }

        private void MoveDirectory(string source, string target)
        {
            try
            {
                var sourcePath = source.TrimEnd('\\', ' ');
                var targetPath = target.TrimEnd('\\', ' ');

                var files = Directory.EnumerateFiles(sourcePath, "*", SearchOption.AllDirectories)
                                    .GroupBy(s => Path.GetDirectoryName(s));

                foreach(var folder in files)
                {
                    var targetFolder = folder.Key.Replace(sourcePath, targetPath);
                    Directory.CreateDirectory(targetFolder);
                    foreach (var file in folder)
                    {
                        var targetFile = Path.Combine(targetFolder, Path.GetFileName(file));
                        if (File.Exists(targetFile)) File.Delete(targetFile);
                        File.Move(file, targetFile);
                    }
                }
            }
            catch (Exception ex)
            {
                // log me
            }
        }

        private void UpdateRunInformation(TestRun run)
        {
            try
            {
                if (run == null)
                {
                    return;
                }

                if (run.Steps.Count > 0)
                {
                    run.TestsPassed = run.Steps.Sum(s => s.TestsPassed);
                    run.TestsFailed = run.Steps.Sum(s => s.TestsFailed);
                    run.TestsSkipped = run.Steps.Sum(s => s.TestsSkipped);
                    run.TestsIgnored = run.Steps.Sum(s => s.TestsIgnored);

                    var activeSteps = run.Steps.Count(x => x.Status == StatusEnum.NotStarted || x.Status == StatusEnum.Queued || x.Status == StatusEnum.Running);
                    if (activeSteps == 0)
                    {
                        if (run.Status != StatusEnum.Cancelled)
                        {
                            run.Status = StatusEnum.Completed;
                        }
                        var duration = (from step in run.Steps select (step.Finish - step.Start).TotalSeconds).Sum();
                        if (duration > 0)
                        {
                            var seconds = Math.Round(duration % 60, 0);
                            run.Duration = $"{Math.Round(duration / 60, 0)}mins {seconds}secs";
                        }
                    }

                    _TestRepository.PersistChanges(run.Id);

                }
            }
            catch (Exception ex)
            {
                // log me
            }
        }

        private async Task CancelTestRun(TestEvent ev)
        {
            try
            {
                if (ev != null)
                {
                    var run = _TestRepository.GetTestRun(ev.RunId);
                    if (run != null && _RunningProcesses.ContainsKey(run.Id))
                    {
                        foreach (var process in _RunningProcesses[run.Id])
                        {
                            try
                            {
                                process.Kill();
                            }
                            catch (Exception ex)
                            {
                                // log me
                            }
                        }

                        run.Steps.ForEach(s => s.Status = StatusEnum.Cancelled);
                        run.Status = StatusEnum.Cancelled;
                        _TestRepository.PersistChanges(run.Id);
                    }
                }
            }
            catch (Exception ex)
            {
                // log me
            }
        }

        private async Task QueueStep(TestEvent ev)
        {
            try
            {
                if (ev != null && ev.StepId.HasValue)
                {
                    var run = _TestRepository.GetTestRun(ev.RunId);
                    var step = _TestRepository.GetTestStep(ev.RunId, ev.StepId.Value);
                    if (run != null && step != null)
                    {
                        if (run.Status != StatusEnum.Cancelled)
                        {
                            run.Status = StatusEnum.Running;
                        }
                        step.Status = StatusEnum.Queued;
                        _StepQueue.Enqueue(new Tuple<TestRun, TestStep>(run, step));
                        StartProcessing();
                    }
                }
            }
            catch (Exception ex)
            {
                // log me
            }
        }
    }
}
