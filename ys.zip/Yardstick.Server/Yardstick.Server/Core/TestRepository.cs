﻿using Microsoft.AspNetCore.SignalR;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reactive.Subjects;
using System.Threading.Tasks;
using Yardstick.Shared;

namespace Yardstick.Server.Core
{
    public class TestRepository
    {
        IConfiguration _Configuration;
        private List<TestRun> _TestRuns;
        private string _DataPath;
        private IHubContext<MessageHub> _HubContext;

        private BehaviorSubject<TestEvent> _OnChangeSubject = new BehaviorSubject<TestEvent>(null);

        public TestRepository(IConfiguration configuration, IHubContext<MessageHub> hubContext)
        {
            _Configuration = configuration;
            _HubContext = hubContext;
            _TestRuns = new List<TestRun>();
            _DataPath = _Configuration["DataPath"];

            LoadTestData();
        }

        private void LoadTestData()
        {
            try
            {
                var path = _DataPath + "\\data.json";
                if (File.Exists(path))
                {
                    using (StreamReader r = new StreamReader(path)) {
                        string json = r.ReadToEnd();
                        var items = JsonConvert.DeserializeObject<List<TestRun>>(json);
                        items.ForEach(run =>
                        {
                            if (run.Status == StatusEnum.Running)
                            {
                                run.Status = StatusEnum.Error;
                            }
                            if (run.Steps != null && run.Steps.Count > 0)
                            {
                                run.Steps.ForEach(step =>
                                {
                                    if (step.Status == StatusEnum.Running)
                                    {
                                        step.Status = StatusEnum.Error;
                                    }
                                });
                            }
                            _TestRuns.Add(run);
                        });
                    }
                }
            }
            catch (Exception ex)
            {
                // log?
                throw ex;
            }
        }

        public IObservable<TestEvent> OnChange => _OnChangeSubject;

        public List<TestRun> GetTestRuns()
        {
            return _TestRuns;
        }

        public TestRun GetTestRun(int id)
        {
            return _TestRuns.FirstOrDefault(x => x.Id == id);
        }

        public TestStep GetTestStep(int runId, int stepId)
        {
            var run = GetTestRun(runId);
            if (run != null)
            {
                var step = run.Steps.FirstOrDefault(x => x.Id == stepId);
                return step;
            }

            return null;
        }

        public void CreateTestRun(EnvironmentEnum environment)
        {
            try
            {
                var id = 1;
                if (_TestRuns.Count > 0)
                {
                    id = _TestRuns.Max(x => x.Id) + 1;
                }

                var run = new TestRun()
                {
                    Id = id,
                    Environment = environment,
                    Status = StatusEnum.NotStarted,
                    Start = DateTime.UtcNow,
                    Version = "TBD"
                };

                _TestRuns.Add(run);

                Task.Factory.StartNew(() =>
                {
                    _OnChangeSubject.OnNext(new TestEvent(TestEventEnum.Created, run.Id));
                    PersistChanges(run.Id);
                });
            }
            catch
            {

            }
        }

        public void ReRunStep(int runId, int stepId)
        {
            try
            {
                var step = GetTestStep(runId, stepId);
                if (step != null)
                {
                    step.Status = StatusEnum.Queued;
                    Task.Factory.StartNew(() =>
                    {
                        _OnChangeSubject.OnNext(new TestEvent(TestEventEnum.Queued, runId, step.Id));
                        PersistChanges(runId);
                    });
                }
            }
            catch(Exception ex)
            {
                // log
            }
        }

        public void CancelTestRun(int runId)
        {
            try
            {
                var run = GetTestRun(runId);
                if (run != null)
                {
                    run.Status = StatusEnum.Cancelled;
                    Task.Factory.StartNew(() =>
                    {
                        _OnChangeSubject.OnNext(new TestEvent(TestEventEnum.Cancelled, runId));
                        PersistChanges(runId);
                    });
                }
            }
            catch (Exception ex)
            {
                // log
            }
        }

        public void DeleteTestRun(int runId)
        {
            try
            {
                var path = Path.Combine(_Configuration["DataPath"], runId.ToString());
                if (Directory.Exists(path))
                {
                    Directory.Delete(path, true);
                }
                _TestRuns.Remove(_TestRuns.FirstOrDefault(x => x.Id == runId));
                PersistChanges(runId);
            }
            catch (Exception ex)
            {
                // log
            }
        }

        public async Task PersistChanges(int runId)
        {
            try
            {
                await Task.Delay(100);

                // send message to UI
                var notificationEvent = new TestRunChangedEvent(runId);
                await _HubContext.Clients.All.SendAsync("RecieveMessage", notificationEvent);

                var path = _DataPath + "\\data.json";
                var json = JsonConvert.SerializeObject(_TestRuns);
                File.WriteAllText(path, json);
            }
            catch
            {
                // log
            }
        }

    }
}
