using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Net.Http.Headers;
using Newtonsoft.Json.Converters;
using Newtonsoft.Json.Serialization;
using Swashbuckle.AspNetCore.Swagger;
using Yardstick.Server.Core;

namespace Yardstick.Server
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddCors(options => options.AddPolicy("CorsPolicy",
                builder => builder.AllowAnyMethod().AllowAnyHeader().AllowCredentials()
                .WithOrigins("http://localhost:7300", "*")));

            services.AddMvc()
                .SetCompatibilityVersion(CompatibilityVersion.Version_2_2)
                .AddJsonOptions(x =>
                {
                    x.SerializerSettings.Converters.Add(new StringEnumConverter());
                    x.SerializerSettings.ContractResolver = new CamelCasePropertyNamesContractResolver();
                });

            services.AddSignalR();

            services.AddSwaggerGen(c =>
            {
                c.CustomSchemaIds(t => t.FullName);
                c.SwaggerDoc("v1", new Info { Title = "Yardstick", Version = "v1" });
            });

            services.AddSingleton<TestRepository>();
            services.AddSingleton<TestEngine>();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            app.Use(async (request, next) =>
            {
                request.Response.Headers[HeaderNames.CacheControl] = "no-store,no-cache";
                request.Response.Headers[HeaderNames.Pragma] = "no-cache";
                await next();
            });

            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseCors("CorsPolicy");
            app.UseSwagger();
            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/v1/swagger.json", "Yardstick");
            });

            app.UseSignalR(config =>
            {
                config.MapHub<MessageHub>("/stream");
            });

            app.UseMvc(routes =>
            {
                routes.MapRoute(name: "default", template: "{controller}/{action}/{id?}");
            });

            ActivatorUtilities.GetServiceOrCreateInstance<TestEngine>(app.ApplicationServices);
        }
    }
}
