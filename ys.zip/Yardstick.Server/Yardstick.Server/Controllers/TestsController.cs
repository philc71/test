﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Yardstick.Server.Core;
using Yardstick.Shared;

namespace Yardstick.Server.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TestsController : ControllerBase
    {
        TestRepository _TestRepository;

        public TestsController(TestRepository testRepository)
        {
            _TestRepository = testRepository;
        }

        [HttpGet("{id}")]
        public TestRun TestRun(int id)
        {
            try
            {
                var result = _TestRepository.GetTestRun(id);
                return result;
            }
            catch (Exception ex)
            {
                // log it
                throw ex;
            }
        }

        [HttpGet("[action]")]
        public IEnumerable<TestRun> TestRuns()
        {
            try
            {
                var result = _TestRepository.GetTestRuns();
                return result;
            }
            catch (Exception ex)
            {
                // log it
                throw ex;
            }
        }

        [HttpPost("[action]")]
        public IActionResult StartTest([FromQuery] int environment)
        {
            try
            {
                _TestRepository.CreateTestRun(Enum.Parse<EnvironmentEnum>(environment.ToString()));
                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500);
            }
        }

        [HttpPost("[action]")]
        public IActionResult ReRunStep([FromBody] int runId, int stepId)
        {
            try
            {
                _TestRepository.ReRunStep(runId, stepId);
                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500);
            }
        }

        [HttpPost("[action]")]
        public IActionResult CancelTestRun([FromBody] int runId)
        {
            try
            {
                _TestRepository.CancelTestRun(runId);
                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500);
            }
        }

        [HttpPost("[action]")]
        public IActionResult DeleteTestRun([FromBody] int runId)
        {
            try
            {
                _TestRepository.DeleteTestRun(runId);
                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500);
            }
        }
    }
}