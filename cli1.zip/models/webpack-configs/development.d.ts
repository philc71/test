import { WebpackConfigOptions } from '../webpack-config';
export declare const getDevConfig: (wco: WebpackConfigOptions) => {};
