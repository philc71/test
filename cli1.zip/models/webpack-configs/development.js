"use strict";
exports.getDevConfig = function (wco) {
    return {};
};
//# sourceMappingURL=/Users/hans/Sources/angular-cli/packages/angular-cli/models/webpack-configs/development.js.map