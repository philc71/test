export { bootstrapItem, insertImport, addPathToRoutes, addItemsToRouteProperties, confirmComponentExport, resolveComponentPath, applyChanges } from '@angular-cli/ast-tools';
