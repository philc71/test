export default function findParentModule(project: any, currentDir: string): string;
