import { GithubPagesDeployOptions } from './github-pages-deploy';
export default function githubPagesDeployRun(options: GithubPagesDeployOptions, rawArgs: string[]): Promise<void>;
