declare const E2eCommand: any;
export default E2eCommand;
