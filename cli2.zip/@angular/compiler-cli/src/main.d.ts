import 'reflect-metadata';
export declare function main(args: any, consoleError?: (s: string) => void): Promise<number>;
