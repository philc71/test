export declare function assertArrayOfStrings(identifier: string, value: any): void;
export declare function assertInterpolationSymbols(identifier: string, value: any): void;
