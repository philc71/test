import { CompileElement } from './compile_element';
export declare function bindQueryValues(ce: CompileElement): void;
