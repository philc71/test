package main

import (
	"fmt"
	"log"
	"net"
	"os"
	"testservice/grpcserver"
	"testservice/proto"

	"google.golang.org/grpc"
	"google.golang.org/grpc/reflection"
)

func main() {
	port := os.Getenv("PORT")

	if port == "" {
		port = "8080"
		fmt.Println("Defaulting port to 8080")
	}
	
	grpcEndpoint := fmt.Sprintf(":%s", port)
	log.Printf("gRPC endpoint [%s]", grpcEndpoint)
	
	grpcServer := grpc.NewServer()
	proto.RegisterCalculatorServer(grpcServer, grpcserver.NewServer()) 
	
	reflection.Register(grpcServer)
	
	listen, err := net.Listen("tcp", grpcEndpoint)
	if err != nil {
		log.Fatal(err)
	}
	log.Printf("Starting: gRPC Listener [%s]\n", grpcEndpoint)
	log.Fatal(grpcServer.Serve(listen))

	// http.HandleFunc("/ping", rest.PingHandler)
	// fmt.Printf("Service started, listening on port: %s", port)
	// err := http.ListenAndServe(":"+port, nil)
	// if err != nil {
	// 	panic(err)
	// }
}
