# build

docker build -t philc71/gcp-testservice:latest .

# run local

docker run -p 8080:8100 -e PORT=8100 philc71/gcp-testservice:latest

# gcp via gcr

gcloud auth login
docker tag philc71/gcp-testservice:latest gcr.io/testwood/philc71/gcp-testservice:latest
docker push gcr.io/testwood/philc71/gcp-testservice:latest

# grpcurl --plaintext -proto proto/calculator.proto -d '{"first_operand": 2.0, "second_operand": 3.0, "operation": "ADD"}' localhost:8080 Calculator.Calculate

# https://github.com/grpc-ecosystem/grpc-cloud-run-example/blob/master/golang/README.md
