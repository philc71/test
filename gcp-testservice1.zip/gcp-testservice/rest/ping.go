package rest

import (
	"encoding/json"
	"net/http"
	"time"
)

type Ping struct {
	RequestTime string `json:"requestTime"`
}

func PingHandler(w http.ResponseWriter, r *http.Request) {
	
	w.Header().Set("Access-Control-Allow-Origin", "*")
	w.Header().Set("Access-Control-Allow-Methods", "POST, GET, OPTIONS, PUT, DELETE")

	response := Ping{RequestTime: time.Now().Local().UTC().String()}
	jsonBytes, err := json.Marshal(response)
	if err != nil {
		w.WriteHeader(http.StatusInternalServerError)
		w.Write([]byte(err.Error()))
	}
	w.Header().Add("content-type", "application/json")
	w.Write(jsonBytes)
}
