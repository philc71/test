# used this to remove generated file(s)

make clean

# used this to generate the pb file

make gen
