package grpcserver

import (
	"context"
	"fmt"
	"log"
	"testservice/proto"
)

// Prove that Server implements pb.CalculatorServer by instantiating a Server
var _ proto.CalculatorServer = (*Server)(nil)

// Server is a struct implements the pb.CalculatorServer
type Server struct {
	proto.UnimplementedCalculatorServer
}

// NewServer returns a new Server
func NewServer() *Server {
	return &Server{}
}

// Calculate performs an operation on operands defined by pb.BinaryOperation returning pb.CalculationResult
func (s *Server) Calculate(ctx context.Context, r *proto.BinaryOperation) (*proto.CalculationResult, error) {
	log.Println("[server:Calculate] Started")
	if ctx.Err() == context.Canceled {
		return &proto.CalculationResult{}, fmt.Errorf("client cancelled: abandoning")
	}

	switch r.GetOperation() {
	case proto.Operation_ADD:
		return &proto.CalculationResult{
			Result: r.GetFirstOperand() + r.GetSecondOperand(),
		}, nil
	case proto.Operation_SUBTRACT:
		return &proto.CalculationResult{
			Result: r.GetFirstOperand() - r.GetSecondOperand(),
		}, nil
	default:
		return &proto.CalculationResult{}, fmt.Errorf("undefined operation")
	}

}