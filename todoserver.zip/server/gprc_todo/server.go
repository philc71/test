package gprc_todo

import (
	"context"
	"fmt"
	"log"
	"todoapp/proto"
)

// Prove that Server implements pb.CalculatorServer by instantiating a Server
var _ proto.ToDoServiceServer = (*Server)(nil)

// Server is a struct implements the pb.CalculatorServer
type Server struct {
	proto.UnimplementedToDoServiceServer
}

// NewServer returns a new Server
func NewServer() *Server {
	return &Server{}
}

func (s *Server) GetAllTasks(ctx context.Context, r *proto.ToDoListRequest) (*proto.ToDoListResponse, error) {
	 	log.Println("[server:GetAllTasks] Started")
	if ctx.Err() == context.Canceled {
		return &proto.ToDoListResponse{}, fmt.Errorf("client cancelled: abandoning")
	}
	return &proto.ToDoListResponse{}, fmt.Errorf("undefined operation")
 }

// rpc AddOrUpdateTask (ToDoMessage) returns (ToDoListResponse);
func (s *Server) AddOrUpdateTask(ctx context.Context, r *proto.ToDoMessage) (*proto.ToDoListResponse, error) {
	log.Println("[server:AddOrUpdateTask] Started")
if ctx.Err() == context.Canceled {
   return &proto.ToDoListResponse{}, fmt.Errorf("client cancelled: abandoning")
}
return &proto.ToDoListResponse{}, fmt.Errorf("undefined operation")
}



// Calculate performs an operation on operands defined by pb.BinaryOperation returning pb.CalculationResult
// func (s *Server) Calculate(ctx context.Context, r *proto.BinaryOperation) (*proto.CalculationResult, error) {

// 	switch r.GetOperation() {
// 	case proto.Operation_ADD:
// 		return &proto.CalculationResult{
// 			Result: r.GetFirstOperand() + r.GetSecondOperand(),
// 		}, nil
// 	case proto.Operation_SUBTRACT:
// 		return &proto.CalculationResult{
// 			Result: r.GetFirstOperand() - r.GetSecondOperand(),
// 		}, nil
// 	default:
// 		return &proto.CalculationResult{}, fmt.Errorf("undefined operation")
// 	}

// }