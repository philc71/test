// Package classification of todo API
//
// Documentation for todo API
//
// Schemes: http
// BasePath: /
// Version: 1.0.0
//
// Consumes:
// - application/json
//
// Produces:
// - application/json
// swagger:meta
package main

import (
	"fmt"
	"log"
	"net"
	"net/http"
	"todoapp/gprc_todo"
	"todoapp/proto"
	"todoapp/router"

	handlers "github.com/gorilla/handlers"
	"google.golang.org/grpc"
	"google.golang.org/grpc/reflection"
)

func main() {
	fmt.Println("Starting server...")

	grpcServer := grpc.NewServer()
	proto.RegisterToDoServiceServer(grpcServer, gprc_todo.NewServer()) 

	reflection.Register(grpcServer)
	
	listen, err := net.Listen("tcp", ":9100")
	if err != nil {
		log.Fatal(err)
	}
	log.Printf("Starting: gRPC Listener\n")
	log.Fatal(grpcServer.Serve(listen))

	r := router.Router();
	cors := handlers.CORS(
		handlers.AllowedHeaders([]string{"content-type"}),
		handlers.AllowedOrigins([]string{"*"}),
		handlers.AllowCredentials(),
	)
	log.Fatal(http.ListenAndServe(":9000", cors(r)))

}