package middleware

import (
	"encoding/json"
	"fmt"
	"net/http"
	"todoapp/models"
)

var collection = make([]models.ToDoList, 0)

// swagger:route GET /api/tasks tasks listTasks
// Returns a list of tasks
// responses:
//  200: ToDoListResponse
func GetAllTasks(w http.ResponseWriter, r *http.Request) {
	fmt.Println("Get all tasks")
	w.Header().Set("Context-Type", "application/x-www-form-urlencoded")
	w.Header().Set("Access-Control-Allow-Origin", "*")
	json.NewEncoder(w).Encode(collection)
}

// swagger:route POST /api/tasks tasks AddOrUpdateTask
// Returns a updated or created task
// responses:
//  200: ToDoListRequest

// swagger:route POST /api/tasks tasks AddOrUpdateTask
// Updates or Creates a new task
//
// responses:
//	200: ToDoResponse
//  422: errorValidation
//  501: errorResponse
func AddOrUpdateTask(w http.ResponseWriter, r *http.Request) {
	fmt.Println("create task")
	w.Header().Set("Context-Type", "application/x-www-form-urlencoded")
	w.Header().Set("Access-Control-Allow-Origin", "*")
	w.Header().Set("Access-Control-Allow-Methods", "POST")
	w.Header().Set("Access-Control-Allow-Headers", "Content-Type")
	var task models.ToDoList
	json.NewDecoder(r.Body).Decode(&task)

	// attempt to find task
	if (task.ID > 0) {
		var idx = getIndex(task.ID)
		if (idx >= 0) {
			fmt.Println("Attempting to update task")
			collection[idx] = task
			json.NewEncoder(w).Encode(task)
		}
	} else {
		var id = len(collection)
		task.ID = uint32(id)+1
		collection = append(collection, task)
		json.NewEncoder(w).Encode(task)
	}
}

// getIndex will find an element (needle) inside an array (haystack)
// if not found the function returns -1
func getIndex(id uint32) int {
    for index, element := range collection {
        if element.ID == id {
            return index
        }
    }
    return -1
}
