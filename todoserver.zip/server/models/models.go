package models

// Validation errors defined as an array of strings
// swagger:response errorValidation
type errorValidationWrapper struct {
	// Collection of the errors
	// in: body
	Body ValidationError
}

// ValidationError is a collection of validation error messages
type ValidationError struct {
	Messages []string `json:"messages"`
}

// No content is returned by this API endpoint
// swagger:response noContentResponse
type noContentResponseWrapper struct {
}

// A list of todos
// swagger:response ToDoListResponse
type ToDoListResponse struct {
	// todos
	// in: body
	Body []ToDoList
}

// A todos
// swagger:response ToDoResponse
type ToDoResponse struct {
	// todos
	// in: body
	Body ToDoList
}

// An ToDoParams model.
//
// This is used for operations that want an ToDo as body of the request
// swagger:parameters createTask
type ToDoParams struct {
	// The todo to submit
	//
	// required: true
	// in: body
	ToDo *ToDoList 
}

// swagger:model
type ToDoList struct {
	ID 		uint32 	`json:"id,omitempty"`
	Task 	string 	`json:"task,omitempty"`
	Status 	bool 	`json:"status,omitempty"`
}

