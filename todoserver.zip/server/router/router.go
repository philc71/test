package router

import (
	"net/http"
	"todoapp/middleware"

	middlewareopenapi "github.com/go-openapi/runtime/middleware"
	"github.com/gorilla/mux"
)


func Router() *mux.Router {
	router := mux.NewRouter();

	router.HandleFunc("/api/tasks", middleware.GetAllTasks).Methods("GET", "OPTIONS")
	router.HandleFunc("/api/tasks", middleware.AddOrUpdateTask).Methods("POST", "OPTIONS")

	ops := middlewareopenapi.RedocOpts{SpecURL: "/swagger.yaml"}
	p := middlewareopenapi.Redoc(ops, nil)
	router.Handle("/docs", p)
	router.Handle("/swagger.yaml", http.FileServer(http.Dir("./")))

	// serve swagger ui
	fs := http.FileServer(http.Dir("./swaggerui/"))
	router.PathPrefix("/swaggerui/").Handler(http.StripPrefix("/swaggerui/", fs))

	return router
}